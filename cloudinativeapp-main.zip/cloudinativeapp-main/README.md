# Cloud Native App
This project is a example of cloud native practices.
